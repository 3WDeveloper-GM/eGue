package handlers

import (
	"errors"
	"net/http"

	"github.com/3WDeveloper-GM/pipeline/pkg/adapter/zs"
	"github.com/3WDeveloper-GM/pipeline/pkg/domain"
	Validator "github.com/3WDeveloper-GM/pipeline/pkg/domain/validator"
	"github.com/3WDeveloper-GM/pipeline/pkg/jsonio"
	"github.com/go-chi/render"
)

type SearchHandler struct {
	searcher DBSearch
	io       jsonio.JsonIORW
}

func NewSearchHandler(searcher DBSearch, io jsonio.JsonIORW) *SearchHandler {
	return &SearchHandler{
		searcher: searcher,
		io:       io,
	}
}

func (sh *SearchHandler) SearchMails(w http.ResponseWriter, r *http.Request) {
	var input zs.SearchRequest

	// read the json from the user
	err := sh.io.ReadJSON(w, r, &input)
	if err != nil {
		NewErrorResponse(w, r, http.StatusInternalServerError, err)
		return
	}

	// validate the json instance
	v := Validator.NewValidator()
	if !domain.ValidateInput(v, &input) {
		errs := errors.Join(v.Errors()...)
		NewErrorResponse(w, r, http.StatusBadRequest, errs)
		return
	}

	// Get the mails with the search method
	returnedMails, err := sh.searcher.Search(domain.Index)
	if err != nil {
		NewErrorResponse(w, r, http.StatusInternalServerError, err)
		return
	}

	render.JSON(w, r, returnedMails)
}
