package handlers

import (
	"context"

	"github.com/3WDeveloper-GM/pipeline/pkg/domain"
)

type DBSearch interface {
	Search(index string) ([]domain.Email, error)
}

type DBIndex interface {
	Index(ctx context.Context, root string) error
}
