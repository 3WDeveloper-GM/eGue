package main

import "github.com/3WDeveloper-GM/pipeline/app"

func main() {

	app := app.NewApplication()
	app.StartApp()

}
