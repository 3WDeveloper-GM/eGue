package app

func (a *Application) setRoutes() {
	a.server.Post("/search", a.dependencies.searchHandler.SearchMails)
	a.server.Get("/index", a.dependencies.indexHandler.IndexMails)
}
